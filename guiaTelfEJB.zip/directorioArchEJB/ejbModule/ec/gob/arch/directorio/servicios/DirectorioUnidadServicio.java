package ec.gob.arch.directorio.servicios;

import javax.ejb.Stateless;
import javax.persistence.Query;

import org.jboss.logging.Logger;

import ec.gob.arch.directorio.Unidad;

@Stateless
public class DirectorioUnidadServicio extends ServicioBase<Unidad>{
	
	
	private static final Logger log = Logger.getLogger("Unidad");
	
	public DirectorioUnidadServicio() {
		super(Unidad.class, DirectorioUnidadServicio.class);
	}
	
	public Unidad buscarPorCodigo(String codigo){
		Unidad result = new Unidad();
		try {
			
			Query q = getEm().createQuery("SELECT a FROM Unidad a WHERE a.codigo = :param");
			q.setParameter("param", codigo);
			result = (Unidad) q.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			//return null;
		}
		return result;
		
	}

}
