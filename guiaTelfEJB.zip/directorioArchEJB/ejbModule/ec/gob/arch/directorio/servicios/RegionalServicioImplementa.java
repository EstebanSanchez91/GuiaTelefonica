package ec.gob.arch.directorio.servicios;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.NoResultException;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

import org.jboss.logging.Logger;

import sicohi.jpa.GeRegional;

public @Stateless
class RegionalServicioImplementa  {
	@PersistenceContext(unitName = "sicohiJPA")
	private EntityManager em;
	private Query query;
	private static final Logger log = Logger.getLogger("RegionalServicioImpl");

	public List<GeRegional> buscarTodos() {
		List<GeRegional> resultado = null;
		try {
			query = em.createNamedQuery("GeRegional.traerTodos");
			resultado = query.getResultList();
		} catch (NoResultException ex) {
		} catch (Exception ex) {
			log.error("GeRegional.traerTodos ERROR->" + ex.getMessage());
		}

		return resultado;
	}
	

	
	public GeRegional buscarPorCodigo(String codigo){
		
		try {
			Query q = em.createQuery("SELECT a FROM GeRegional a WHERE TRIM(a.rdhCodigo) = :param");
			q.setParameter("param", codigo);
			return (GeRegional) q.getSingleResult();
		} catch (Exception e) {
			e.printStackTrace();
			return null;
		}
		
	}
	

}
