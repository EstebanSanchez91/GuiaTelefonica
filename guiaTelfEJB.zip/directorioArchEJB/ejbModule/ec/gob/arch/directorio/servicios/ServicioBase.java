package ec.gob.arch.directorio.servicios;

import java.util.List;

import javax.annotation.PostConstruct;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.criteria.CriteriaQuery;

import org.jboss.logging.Logger;

public abstract class ServicioBase<T> {
	
	@PersistenceContext(unitName = "comercializacionJPA")	
	private EntityManager em;
	
	protected static Logger LOG;
	private Class<T> tipoEntidad;
	private Class<?> tipoServicio;

	public ServicioBase(Class<T> tipoEntidad, Class<?> tipoServicio) {
		this.tipoEntidad = tipoEntidad;
		this.tipoServicio = tipoServicio;
	}

	public T insertar(T entidad) throws Exception{
		try {			
			em.persist(entidad);
			em.flush();
			LOG.info("Insertando Entidad >> " + entidad);
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
			entidad = null;
			throw new Exception("ERROR Insertando Entidad >> "+entidad);
		}
		return entidad;
		
	}

	public void actualizar(T entidad) throws Exception{
		try {
			em.merge(entidad);
			LOG.info("Actualizando Entidad >>" + entidad);
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
			throw new Exception("ERROR Actualizando Entidad >> "+entidad);
		}		
	}
	
	public void eliminar(T entidad) throws Exception{		
		try {
			LOG.info("Eliminando Entidad >>" + entidad);
			em.remove(em.merge(entidad)); 
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
			throw new Exception("ERROR Eliminando Entidad >> "+entidad);
		}
	}

	public T buscarPorId(long id){
		try {
			LOG.info("Buscando "+tipoEntidad+" con id >> " + id);
			return em.find(tipoEntidad, id);
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
			LOG.error("ERROR: Buscando "+tipoEntidad+" con id >> " + id);
			return null;
		}
		
	}

	@SuppressWarnings({ "unchecked", "rawtypes" })
	public List<T> buscarTodos() {
		try {
			CriteriaQuery cq = em.getCriteriaBuilder().createQuery();
			cq.select(cq.from(tipoEntidad));
			LOG.info("Buscar Todos >> "+tipoEntidad);
			return em.createQuery(cq).getResultList();
		} catch (Exception e) {
			LOG.error("Error: " + e.getMessage());
			LOG.error("ERROR Buscar Todos >> "+tipoEntidad);
			return null;
		}
		
	}

	@PostConstruct
	private void setLogger() {
		if (LOG == null) {
			LOG = Logger.getLogger(tipoServicio);
		}
	}

	public EntityManager getEm() {
		return em;
	}

	public void setEm(EntityManager em) {
		this.em = em;
	}

}
