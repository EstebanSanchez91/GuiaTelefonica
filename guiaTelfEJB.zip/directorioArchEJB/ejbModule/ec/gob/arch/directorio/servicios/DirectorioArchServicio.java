package ec.gob.arch.directorio.servicios;

import java.util.List;

import javax.ejb.Stateless;
import javax.persistence.NoResultException;
import javax.persistence.Query;

import org.jboss.logging.Logger;

import ec.gob.arch.directorio.DirectorioArch;

@Stateless
public class DirectorioArchServicio extends ServicioBase<DirectorioArch>{
	
	public DirectorioArchServicio() {
		super(DirectorioArch.class, DirectorioArchServicio.class);
	}
	

	private Query query;
	private static final Logger log = Logger.getLogger("DirectorioArch");

	
	
	public void actualizar(DirectorioArch directorio) throws Exception {
		try {
			getEm().merge(directorio);
		} catch (Exception e) {
			log.error("DirectorioArch.actualizar ERROR->" + e.getMessage());
			throw new Exception("Error en actualizaci�n Directorio "+ e.getMessage());
		}
		
	}
	
	//busqueda por usuario
	public List<DirectorioArch> buscaUsuario(String identificacion) 
	{
		List<DirectorioArch> listaUsuarios = null;
		try {
			query = getEm().createQuery("SELECT a FROM DirectorioArch a WHERE UPPER(a.nombres) like UPPER(:nombres) and a.estado ='A'" );             
			query.setParameter("nombres", "%" + identificacion + "%");
			listaUsuarios = query.getResultList();
		} 
		catch (NoResultException ex) 
		{
			ex.printStackTrace();
		} 
		catch (Exception ex) 
		{
			ex.printStackTrace();
			log.error("DirectorioArch.buscaUsuario ERROR->" + ex.getMessage());
		}

		return listaUsuarios;

	}
	
	//busqueda por usuario
		public List<DirectorioArch> buscaUsuarioAdm(String identificacion) 
		{
			List<DirectorioArch> listaUsuarios = null;
			try {
				query = getEm().createQuery("SELECT a FROM DirectorioArch a WHERE UPPER(a.nombres) like UPPER(:nombres)" );             
				query.setParameter("nombres", "%" + identificacion + "%");
				listaUsuarios = query.getResultList();
			} 
			catch (NoResultException ex) 
			{
				ex.printStackTrace();
			} 
			catch (Exception ex) 
			{
				ex.printStackTrace();
				log.error("DirectorioArch.buscaUsuario ERROR->" + ex.getMessage());
			}

			return listaUsuarios;

		}
	
	//busqueda por regional
	
	public List<DirectorioArch> buscaUsuarioPorRegional(String codigo) 
	{
		List<DirectorioArch> listaReg = null;
		try {
			query = getEm().createQuery("SELECT a FROM DirectorioArch a WHERE a.codRegional = :codigo and a.estado = 'A'" );             
			query.setParameter("codigo",codigo);
			listaReg = query.getResultList();
		} 
		
		catch (Exception ex) 
		{
			ex.printStackTrace();
			log.error("DirectorioArch.buscaUsuarioPorRegional ERROR->" + ex.getMessage());
		}

		return listaReg;

	}
	
	//busqueda por nombre y regional
	public List<DirectorioArch> buscaTodas(String codigo, String identificacion) 
	{
		List<DirectorioArch> listaReg = null;
		try {
			query = getEm().createQuery("SELECT a FROM DirectorioArch a WHERE a.codRegional = :codigo and UPPER(a.nombres) like UPPER(:nombres) and a.estado = 'A'" );             
			query.setParameter("codigo",codigo);
			query.setParameter("nombres", "%" + identificacion + "%");
			listaReg = query.getResultList();
		} 
		
		catch (Exception ex) 
		{
			ex.printStackTrace();
			log.error("DirectorioArch.buscaUsuarioPorRegional ERROR->" + ex.getMessage());
		}

		return listaReg;

	}
	
	//trae toda la lista de unidad
	
//	public List<DirectorioUnidad> buscaTodos() {
//		List<DirectorioUnidad> resultado = null;
//		try {
//			query = em.createNamedQuery("DirectorioUnidad.traerTodos");
//			resultado = query.getResultList();
//		} catch (NoResultException ex) {
//		} catch (Exception ex) {
//			log.error("DirectorioUnidad.traerTodos ERROR->" + ex.getMessage());
//		}
//
//		return resultado;
//	}
}
