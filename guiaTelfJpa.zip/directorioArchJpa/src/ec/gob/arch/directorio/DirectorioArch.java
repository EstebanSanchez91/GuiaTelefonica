package ec.gob.arch.directorio;

import java.io.Serializable;

import javax.persistence.*;


/**
 * The persistent class for the DIRECTORIO_ARCH database table.
 * 
 */
@Entity
@Table(name="DIRECTORIO_ARCH")
@NamedQuery(name="DirectorioArch.findAll", query="SELECT d FROM DirectorioArch d")
public class DirectorioArch implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@SequenceGenerator(name = "DIRECTORIO_ARCH_GEN", sequenceName = "DIRECTORIO.DIRECTORIO_ARCH_SEQ",allocationSize = 1)
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "DIRECTORIO_ARCH_GEN")
	private long codigo;

	private String cargo;

	private String ciudad;
	
	@Transient
	private String regional;
	
	@Transient
	private String unidad;
	
	@Transient
	private boolean activo;
	
	@Column(name="COD_REGIONAL")
	private String codRegional;

	@Column(name="COD_UNIDAD")
	private String codUnidad;

	@Column(name="CORREO_ELECTRONICO")
	private String correoElectronico;

	private String direccion;

	private String estado;

	private String extension;

	private String nombres;

	private String telefono;
	

	public DirectorioArch() {
	}

	public long getCodigo() {
		return this.codigo;
	}

	public void setCodigo(long codigo) {
		this.codigo = codigo;
	}

	public String getCargo() {
		return this.cargo;
	}

	public void setCargo(String cargo) {
		this.cargo = cargo;
	}

	public String getCiudad() {
		return this.ciudad;
	}

	public void setCiudad(String ciudad) {
		this.ciudad = ciudad;
	}

	public String getCodRegional() {
		return this.codRegional;
	}

	public void setCodRegional(String codRegional) {
		this.codRegional = codRegional;
	}

	public String getCodUnidad() {
		return this.codUnidad;
	}

	public void setCodUnidad(String codUnidad) {
		this.codUnidad = codUnidad;
	}

	public String getCorreoElectronico() {
		return this.correoElectronico;
	}

	public void setCorreoElectronico(String correoElectronico) {
		this.correoElectronico = correoElectronico;
	}

	public String getDireccion() {
		return this.direccion;
	}

	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}

	public String getEstado() {
		return this.estado;
	}

	public void setEstado(String estado) {
		this.estado = estado;
	}

	public String getExtension() {
		return this.extension;
	}

	public void setExtension(String extension) {
		this.extension = extension;
	}

	public String getNombres() {
		return this.nombres;
	}

	public void setNombres(String nombres) {
		this.nombres = nombres;
	}

	public String getTelefono() {
		return this.telefono;
	}

	public void setTelefono(String telefono) {
		this.telefono = telefono;
	}

	public String getRegional() {
		return regional;
	}

	public void setRegional(String regional) {
		this.regional = regional;
	}

	public String getUnidad() {
		return unidad;
	}

	public void setUnidad(String unidad) {
		this.unidad = unidad;
	}

	public boolean getActivo() {
		return activo;
	}

	public void setActivo(boolean activo) {
		this.activo = activo;
	}

}