package ec.arch.gob.ec.directorioTelefonico.controladores;

import java.util.ArrayList;
import java.util.List;

import javax.annotation.PostConstruct;
import javax.ejb.EJB;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;

import sicohi.jpa.GeRegional;
import sicohi.utils.GeneralBackingBeans;
import sicohi.utils.MensajesInformacion;
import sicohi.utils.MensajesPagina;
import ec.gob.arch.directorio.DirectorioArch;
import ec.gob.arch.directorio.Unidad;
import ec.gob.arch.directorio.servicios.DirectorioArchServicio;
import ec.gob.arch.directorio.servicios.DirectorioUnidadServicio;
import ec.gob.arch.directorio.servicios.RegionalServicioImplementa;

@ManagedBean
@ViewScoped //view solo ver datos y si refresco se borran no permanecen como session
public class directorioTelefonicoBean extends GeneralBackingBeans{
	

	private String regionalSeleccionada; 
	private List<GeRegional> listaReg;
	private GeRegional entidadReg;
	private GeRegional entidadReg1;
	private List<DirectorioArch> listaDirectorio;
	private DirectorioArch directorio;
	private String identificacion,nombre;
	private String codReg;
	private String desUnidad;
	private String codUnidad;
	private List<Unidad> listaUnidad;
	private Unidad unidad;
	private Unidad entidadUni;
	//private Boolean bandera = false ;
	private String flag;
	

	@EJB
	public RegionalServicioImplementa servicioRegional;
	
	@EJB
	public DirectorioArchServicio servicioDirectorio;
	
	@EJB
	public DirectorioUnidadServicio servicioUnidad;
	
	
	@PostConstruct
	public void inicio() {
		this.getNombre();
		listaReg = servicioRegional.buscarTodos();//llena la lista regionales
		listaUnidad = servicioUnidad.buscarTodos();//llena lista unidad
	}
	
	/**
	 * Constructor
	 */
	public directorioTelefonicoBean() {
		nuevaListaRegionales();
		nuevaListaDirectorio();
		nuevaListaUnidad();
		directorio = new DirectorioArch();
		unidad = new Unidad();
	}
	
	public void nuevaListaRegionales() {
		listaReg = new ArrayList<GeRegional>();
	}
	
	public void nuevaListaDirectorio(){
		listaDirectorio = new ArrayList<DirectorioArch>();
		directorio = new DirectorioArch();
	}
	
	public void nuevaListaUnidad(){
		listaUnidad = new ArrayList<Unidad>();
		unidad = new Unidad();
	}
	
	/**
	 * Metodo para buscar usuarios por nombres
	 */
	
	public void buscarUsuario() {
		nuevaListaDirectorio();
		
		
		listaDirectorio = servicioDirectorio.buscaUsuario(nombre);
		
		
		for (DirectorioArch d:listaDirectorio){
			
			entidadReg1 = servicioRegional.buscarPorCodigo(d.getCodRegional());
			entidadUni = servicioUnidad.buscarPorCodigo(d.getCodUnidad());
			
			d.setRegional(entidadReg1.getRdhDescripcion());
			d.setUnidad(entidadUni.getUnidad());
			
		}
	}
	
	public void buscarUsuarioAdm() {
		
		nuevaListaDirectorio();
		
		
		listaDirectorio = servicioDirectorio.buscaUsuarioAdm(nombre);
		
		
		for (DirectorioArch d:listaDirectorio){
			
			entidadReg1 = servicioRegional.buscarPorCodigo(d.getCodRegional());
			entidadUni = servicioUnidad.buscarPorCodigo(d.getCodUnidad());
			
			d.setRegional(entidadReg1.getRdhDescripcion());
			d.setUnidad(entidadUni.getUnidad());
			if(d.getEstado().equals("A")){
				d.setActivo(true);

			}else{
				d.setActivo(false);
			}
			
		}
		
	}
	
	
	
	public void limpiar() {
		
		nuevaListaDirectorio();	
		regionalSeleccionada = "0";
		nombre ="";
		directorio = new DirectorioArch();
		//bandera = false;
	}
	
	public void limpiarDatos() {
		
		nuevaListaDirectorio();
		regionalSeleccionada ="0";
		codUnidad = "0";
		nombre = "";
	}
	
	/**
	 * Metodo para buscar usuarios por regional
	 */
	
	public void buscarUsuarioPorRegional() {
	
		nuevaListaDirectorio();

		if (nombre == null){
			listaDirectorio = servicioDirectorio.buscaUsuarioPorRegional(regionalSeleccionada);
		}else{
			listaDirectorio = servicioDirectorio.buscaTodas(regionalSeleccionada, nombre);
		}

		for (DirectorioArch d:listaDirectorio){
			
			entidadReg1 = servicioRegional.buscarPorCodigo(d.getCodRegional());
			entidadUni = servicioUnidad.buscarPorCodigo(d.getCodUnidad());
			d.setRegional(entidadReg1.getRdhDescripcion());
			d.setUnidad(entidadUni.getUnidad());
			
		}
		
		if (regionalSeleccionada == null)
		{
			mensajeGeneral("Directorio", "","Por favor seleccione una regional", FacesMessage.SEVERITY_ERROR);
		}
		
	}
	
	//metodo para guardar datos
	
	public void guardarDatos() {
		
	//valida si hay datos
		codReg = directorio.getCodRegional();
		codUnidad = directorio.getCodUnidad();
		desUnidad = unidad.getUnidad();
		
		
		if (directorio.getNombres().isEmpty()){
		
			 MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_NOMBRES);
			
		}else if (directorio.getCodRegional().equals("0")){
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_REGIONAL);

		}else if (directorio.getTelefono().isEmpty()) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_TELFONO);
			
		}else if (directorio.getExtension().isEmpty()) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_EXTENSION);
		
		}else if (directorio.getCodUnidad().equals("0")) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_UNIDAD);
			
		}else if (directorio.getCiudad().isEmpty()) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_CIUDAD);
			
		}else if (directorio.getDireccion().isEmpty()) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_DIRECCION);
			
		}else if (directorio.getCorreoElectronico().isEmpty()) {
			MensajesPagina.mostrarMensajeError(MensajesInformacion.FALTA_CE);
		}else{
			
			
			//inserta
			if(listaDirectorio.isEmpty()){
				try {
						
						entidadReg = servicioRegional.buscarPorCodigo(codReg);
						directorio.setCodRegional(codReg);
						entidadUni = servicioUnidad.buscarPorCodigo(codUnidad);
						directorio.setCodUnidad(codUnidad);
						act();
						servicioDirectorio.insertar(directorio);
						limpiarDatos();
						
						MensajesPagina.mostrarMensajeInformacion(MensajesInformacion.INGRESO_CORRECTO);
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					MensajesPagina.mostrarMensajeError(MensajesInformacion.DATOS_NOINGRESADOS);
				}
			}else{
				try {
						//actualiza
						entidadReg = servicioRegional.buscarPorCodigo(codReg);
						directorio.setCodRegional(codReg);
						entidadUni = servicioUnidad.buscarPorCodigo(codUnidad);
						directorio.setCodUnidad(codUnidad);
						act();
						servicioDirectorio.actualizar(directorio);
						limpiarDatos();
						MensajesPagina.mostrarMensajeInformacion(MensajesInformacion.DATOS_ACTUALIZADOS);
						
				} catch (Exception e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
					MensajesPagina.mostrarMensajeError(MensajesInformacion.DATOS_NOACTUALIZADOS);
				}
			}
		}
		
	}
	
	//METODO ACTIVO INACTIVO
	
	
	public void act(){
		
			 if ((directorio.getActivo()==true)){
				 directorio.setEstado("A");
			 }else{
				 directorio.setEstado("I");
			 }
		
	}
	

	/**
	 * 
	 * Getters y Setters
	 */
	
	public String getRegionalSeleccionada() {
		return regionalSeleccionada;
	}

	public void setRegionalSeleccionada(String regionalSeleccionada) {
		this.regionalSeleccionada = regionalSeleccionada;
	}

	public List<GeRegional> getListaReg() {
		return listaReg;
	}

	public void setListaReg(List<GeRegional> listaReg) {
		this.listaReg = listaReg;
	}

	public List<DirectorioArch> getListaDirectorio() {
		return listaDirectorio;
	}

	public void setListaDirectorio(List<DirectorioArch> listaDirectorio) {
		this.listaDirectorio = listaDirectorio;
	}

	public String getIdentificacion() {
		return identificacion;
	}

	public void setIdentificacion(String identificacion) {
		this.identificacion = identificacion;
	}

	public String getNombre() {
		return nombre;
	}

	public void setNombre(String nombre) {
		this.nombre = nombre;
	}


	public DirectorioArch getDirectorio() {
		return directorio;
	}

	public void setDirectorio(DirectorioArch directorio) {
		this.directorio = directorio;
	}

	public String getCodReg() {
		return codReg;
	}

	public void setCodReg(String codReg) {
		this.codReg = codReg;
	}

	public List<Unidad> getListaUnidad() {
		return listaUnidad;
	}

	public void setListaUnidad(List<Unidad> listaUnidad) {
		this.listaUnidad = listaUnidad;
	}

	public Unidad getUnidad() {
		return unidad;
	}

	public void setUnidad(Unidad unidad) {
		this.unidad = unidad;
	}

	public String getCodUnidad() {
		return codUnidad;
	}

	public void setCodUnidad(String codUnidad) {
		this.codUnidad = codUnidad;
	}

	public String getFlag() {
		return flag;
	}

	public void setFlag(String flag) {
		this.flag = flag;
	}


}
