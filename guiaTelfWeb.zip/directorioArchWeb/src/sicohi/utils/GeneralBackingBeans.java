/* 
 * ' * Copyright 2012 AGENCIA DE REGULACIÃ“N Y CONTROL HIDROCARBURÃ�FERO'.
 * ' * Todos los derechos reservados.'. 
 * */
package sicohi.utils;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;

import javax.faces.application.FacesMessage;
import javax.faces.application.FacesMessage.Severity;
import javax.faces.context.FacesContext;
import javax.servlet.ServletContext;
import javax.servlet.ServletOutputStream;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.jboss.logging.Logger;

public class GeneralBackingBeans {
	
	private static final Logger log = Logger.getLogger(GeneralBackingBeans.class
			.getName());

	/**
     * Metodo que presenta los mensajes dentro de la pagina.
     *
     * @param formulario Id del formulario de la pagina donde se mostrara el mensaje.
     * @param summary Un pequemo resumen del mensaje.
     * @param detail Detalle del mensaje, este se presentara en la pantalla.
     * @param severity El tipo de mensaje, se puede utilizar : FacesMessage.SEVERITY_INFO, FacesMessage.SEVERITY_WARN, FacesMessage.SEVERITY_ERROR o FacesMessage.SEVERITY_FATAL
     */
    protected void mensajeGeneral(String formulario, String summary, String detail, Severity severity) {
        mensajeGeneral(formulario, "mensajes", summary, detail, severity);
    }
    
    protected void mensajeGeneralPopUp(String formulario, String summary, String detail, Severity severity) {
        mensajeGeneral(formulario, "mensajesPopUp", summary, detail, severity);
    }

    /**
     * Metodo que presenta los mensajes dentro de la pagina.
     *
     * @param formulario Id del formulario de la pagina donde se mostrara el mensaje.
     * @param campo Id del campo en donde se mostrara el mensaje de error.
     * @param summary Un pequeno resumen del mensaje.
     * @param detail Detalle del mensaje, este se presentara en la pantalla.
     * @param severity El tipo de mensaje, se puede utilizar : FacesMessage.SEVERITY_INFO, FacesMessage.SEVERITY_WARN, FacesMessage.SEVERITY_ERROR o FacesMessage.SEVERITY_FATAL
     */
    protected void mensajeGeneral(String formulario, String campo, String summary, String detail, Severity severity) {
        FacesContext context = FacesContext.getCurrentInstance();
        FacesMessage message = new FacesMessage();
        message.setSeverity(severity);
        message.setSummary(detail);
        message.setDetail(summary );
        context.addMessage(formulario + ":" + campo, message);
    }
    
    /**
     * @param respuesta para descargar reporte;
     * @param tipo de dato q contiene esquema de reporte.
     * @param nombre de reporte.
     * 
     * */
    public void desplegarPDF (HttpServletResponse response,byte[] bytes,String nombreReporte)
	{
		
		response.setHeader("Content-Disposition","attachment; filename="+nombreReporte);
		response.setContentType("application/pdf");
		response.setContentLength(bytes.length);
		ServletOutputStream ouputStream;

		try {
			ouputStream = response.getOutputStream();
			ouputStream.write(bytes, 0, bytes.length);
			ouputStream.flush();
			ouputStream.close();
			FacesContext.getCurrentInstance().responseComplete();
		} catch (IOException e) {
			log.info("ERROR ->" + e.getMessage());
			   mensajeGeneral("proveedores", "ERROR:", "ERROR:", FacesMessage.SEVERITY_FATAL);
		}

		
	}
    
public void descargarFormatos(String formato){
		
		ServletContext context = (ServletContext) FacesContext
				.getCurrentInstance().getExternalContext().getContext();
		
		File filename = new File(
				context.getRealPath("/manuales/"+formato+".pdf"));
		
		try {
			FileInputStream is = new FileInputStream(filename);
		    HttpServletResponse response = (HttpServletResponse)FacesContext.getCurrentInstance().getExternalContext().getResponse();
		    response.setContentType("application/pdf");
		    response.addHeader("Content-disposition", "attachment; filename=\"Instructivo"+formato+".pdf\"");
		    OutputStream os = response.getOutputStream(); 
		    byte[] buffer = new byte[1024];
		    int read = is.read(buffer);
		    while (read >= 0) {
		        if (read > 0) {
		            os.write(buffer, 0, read);
		        }
		        read = is.read(buffer);
		    }
		    is.close();
		    os.close();
		    FacesContext.getCurrentInstance().responseComplete();
		} catch (Exception e) {
		    
		        e.printStackTrace();  
		    }
		

		
	}
    
    
    protected FacesContext context() {
		return (FacesContext.getCurrentInstance());
	}
    
    protected HttpServletRequest getHttpServletRequest() {
		return ((HttpServletRequest) context().getExternalContext()
				.getRequest());
	}
   
    
}
