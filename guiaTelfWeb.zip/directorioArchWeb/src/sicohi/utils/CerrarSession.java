/* 
 * ' * Copyright 2012 AGENCIA DE REGULACIÃ“N Y CONTROL HIDROCARBURÃ�FERO'.
 * ' * Todos los derechos reservados.'. 
 * */
package sicohi.utils;

import java.util.Enumeration;

import javax.servlet.http.HttpServletRequest;

import org.jboss.logging.Logger;

public class CerrarSession {
	private static final Logger log = Logger.getLogger(CerrarSession.class
			.getName());

    /**
     * Metodo  cierra la session.
     *
     * @param request  HttpServletRequest.
     */
    public void invalidarSession(HttpServletRequest request) {
        borrarTodoDelSession(request);
        request.getSession().invalidate();
    }

    /**
     * Metodo borra informacion del request y session.
     *
     * @param request  objeto HttpServletRequest.
     */
    public void borrarTodoDelSession(HttpServletRequest request) {
        Enumeration<?> datosSession = request.getSession().getAttributeNames();
        while (datosSession.hasMoreElements()) {
            Object datoSession = datosSession.nextElement();
            log.info("Elemento a borrarse de la session: " + ((String) datoSession));
            request.getSession().removeAttribute((String) datoSession);
        }

        Enumeration<?> datosRequest = request.getAttributeNames();
        while (datosRequest.hasMoreElements()) {
            Object datoRequest = datosRequest.nextElement();
            log.info("Elemento a borrarse del request: " + ((String) datoRequest));
            request.removeAttribute((String) datoRequest);
        }
    }
}
