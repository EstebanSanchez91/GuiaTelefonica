package sicohi.utils;

import java.util.Properties;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Email {

	public void sfmNotificacion(String envia, String recibe, String asunto,String titulo, String contenido, String url) throws Exception {
		String to = recibe;
		String from = envia;
		String host = "172.16.41.20";
		
		try {
			Properties properties = System.getProperties();
			properties.setProperty("mail.transport.protocol", "smtp");
		    properties.setProperty("mail.smtp.host", host);
			properties.setProperty("mail.smtp.timeout", "50000");
			properties.setProperty("mail.smtp.port","25");				
									
		    Session session = Session.getDefaultInstance(properties);
			session.setDebug(true);			
						
			
     		MimeMessage message = new MimeMessage(session);
			message.setFrom(new InternetAddress(from));
			message.addRecipient(Message.RecipientType.TO, new InternetAddress(
					to));
			message.setSubject(asunto);

			String contenidoFinal = "<html><head>"
					+ "<meta http-equiv='Content-Type' content='text/html; charset=utf-8'>"
					+ "<title>Notificacion Automatica</title></head><body><div align='center'>"
					+ "<font color='#333333' size='1' face='Arial, Helvetica, sans-serif'>"
					+ "</font></div><br><table border='0' cellspacing='0' cellpadding='0' width='704' align='center'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td width='704'><table border='0' cellspacing='0' cellpadding='0' width='704'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td style='LINE-HEIGHT: 0px; FONT-SIZE: 1px'><a href='http://www.arch.gob.ec/'><img style='DISPLAY: block' border='0' src='http://www.arch.gob.ec/images/tics.png' width='710' height='70'></a></td>"
					+ "<td style='LINE-HEIGHT: 0px; FONT-SIZE: 1px'></td>"
					+ "</tr>"
					+ "<tr>"
					+ "<td style='BORDER: #cccccc 1px solid; PADDING-LEFT: 25px' height='98'><table cellspacing='0' cellpadding='2' width='100%' align='center'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td><font style='PADDING-BOTTOM: 3px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 18px; PADDING-TOP: 0px'><strong>Cuant�as Dom�sticas</strong></font></td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "</td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "</td>"
					+ "</tr>"
					+ "<tr>"
					+ "<td style='BORDER-BOTTOM: #cccccc 1px solid; BORDER-LEFT: #cccccc 1px solid; BORDER-RIGHT: #cccccc 1px solid'><table border='0' cellspacing='0' cellpadding='0' width='100%'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td style='PADDING-BOTTOM: 2px; PADDING-LEFT: 25px; PADDING-RIGHT: 15px; PADDING-TOP: 2px' bgcolor='#f1f1f1' valign='top'><table border='0' cellspacing='0' cellpadding='0' width='100%'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td><br><br>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td width='5%'>*</td>"
					+ "<td width='95%'><span style='PADDING-BOTTOM: 6px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 14px; PADDING-TOP: 0px'><strong>Estimado/a reciba un cordial saludo de la ARCH, este e-mail es una notificaci�n electr�nica de Cuant�as Dom�sticas.</strong></span></td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "<br><font style='FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 12px'>"
					+ contenido
					+ "<br><br></font><br><table border='0' cellspacing='0' cellpadding='2' width='100%' align='center'>"
					+ "<font style='FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 12px'>Link de acceso al Sistema: <a style='COLOR: #1f4f82' href='http://siscoh.arch.gob.ec/comercializacionCldhWeb/faces/protegido/inicio.xhtml' target='_blank'>M�dulo Cuant�as Dom�sticas (Solicitante).</a></font>"
					+ "<br><font style='FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 12px'>AYUDA: <a style='COLOR: #1f4f82' href='http://www.arch.gob.ec/index.php/aplicaciones.html' target='_blank'>Manual de usuario</a><br><br></font>"
					+ "<table border='0' cellspacing='0' cellpadding='2' width='100%' align='center'>"
					+ "<td width='95%'><span style='PADDING-BOTTOM: 6px; MARGIN: 0px; PADDING-LEFT: 0px; PADDING-RIGHT: 0px; FONT-FAMILY: Arial, Helvetica, sans-serif; COLOR: #333333; FONT-SIZE: 14px; PADDING-TOP: 0px'><strong>Esta informaci�n es confidencial, por lo que se recomienda tomar las precauciones del caso. Recuerde que toda operaci�n realizada con su USUARIO y CLAVE personal es bajo su responsabilidad.</strong></span></td>"				
					+ "</table>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "<br></td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "</td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "<table border='0' cellspacing='0' cellpadding='0' width='704' align='center'>"
					+ "<tbody>"
					+ "<tr>"
					+ "<td height='6'>&nbsp;</td>"
					+ "<td height='6'></td>"
					+ "</tr>"
					+ "<tr>"
					+ "<td height='6' colspan='2'><p><font color='#333333' size='2' face='Arial, Helvetica, sans-serif'>NO RESPONDA a este correo electr�nico. No podemos dar respuesta a preguntas enviadas a esta direcci�n.Si desea recibir respuesta a sus preguntas y para MAYOR INFORMACI�N escr�banos a: soportearch@arch.gob.ec<br></p>"
					+ "</td>"
					+ "</tr>"
					+ "</tbody>"
					+ "</table>"
					+ "</body></html>";
			message.setContent(contenidoFinal, "text/html");
			
			
			

			Transport.send(message);
		} catch (MessagingException mex) {
			mex.printStackTrace();
			throw new MessagingException("Error al enviar el correo: "
					+ mex.getMessage());
		}
	}
	

	class SMTPAuthentication extends javax.mail.Authenticator
	{

	public PasswordAuthentication getPasswordAuthentication()
	{

	//String username = "rnnr\\cevallofr";

	//String password = "Enero2015";
		
    String username = "francis.cevallosg@gmail.com";
	String password = "francis11";

	return new PasswordAuthentication(username, password);

	}

	}

}
