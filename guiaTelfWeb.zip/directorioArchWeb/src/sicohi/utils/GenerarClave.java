package sicohi.utils;

import java.util.Random;

public class GenerarClave {
	
	
	public static String getRandomString(int length) {
	       final String characters = "ABCDEFGHIJLMNOPQRSTUVWXYZ1234567890";
	       StringBuilder result = new StringBuilder();
	       while(length > 0) {
	           Random rand = new Random();
	           result.append(characters.charAt(rand.nextInt(characters.length())));
	           length--;
	       }
	       return result.toString();
	    }

}
