package sicohi.utils;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.sql.Time;
import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class Convertidor {
	
	/**
	 * Captura fecha y hora del Sistema en Date
	 * @return Day MM dd HH:mm:ss COT yyyy
	 */
	public static Date horafechaSistemaDate(){
        return new Date(System.currentTimeMillis());
    }
	
	/**
	 * Captura fecha y hora del Sistema en Timestamp
	 * @return dd-MM-yyyy HH:mm:ss
	 */
	public static Timestamp horafechaSistemaTimestamp(){
        return new Timestamp(System.currentTimeMillis());
    }
	
	/**
	 * Captura fecha y hora del Sistema en Time
	 * @return HH:mm:ss
	 */
	public static Time horafechaSistemaTime(){
        return new Time(System.currentTimeMillis());
    }

	
	/**
	 * Convierte un Time en String
	 * @param HH:mm:ss
	 * @return "HH:mm:ss"
	 */
	public static String timeAString(Time time){
		SimpleDateFormat sdf  = new SimpleDateFormat("HH:mm:ss");
		//format (date o time -> text)
		String strHora = sdf.format(time); 
		return strHora;
	}
	
	/**
	 * Convierte un Date en String
	 * @param Day MM dd HH:mm:ss COT yyyy
	 * @return "MM-dd-yyyy"
	 */
	public static String dateAfechaString(Date date){		
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd");
		//format (date o time -> text)
		String strFecha = sdf.format(date); 
		return strFecha;
	}
	
	//SIMILAR AL ANTERIOR PERO LA DIFERENCIA ES QUE EN SimpleDateFormat DEFINO LO QUE QUIERO QUE RETORNE
	/**
	 * Convierte un Date en String
	 * @param Day MM dd HH:mm:ss COT yyyy
	 * @return "MM-dd-yyyy HH:mm:ss"
	 */
	public static String dateAString(Date date){		
		SimpleDateFormat sdf  = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//format (date o time -> text)
		String strFecha = sdf.format(date); 
		return strFecha;
	}
	
	/**
	 * 
	 * @param date
	 * @return "dd/MM/aaaa"
	 */
	public static String dateAStringDEFAULT(Date date) {
		DateFormat df = DateFormat.getDateInstance();
		String s =  df.format(date);
		return s;
	}
	
	/**
	 * 
	 * @param date
	 * @return "dd/MM/aa"
	 */
	public static String dateAStringSHORT(Date date) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.SHORT);
		String s =  df.format(date);
		return s;
	}
	
	/**
	 * 
	 * @param date
	 * @return "dd/MM/aaaa"
	 */
	public static String dateAStringMEDIUM(Date date) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.MEDIUM);
		String s =  df.format(date);
		return s;
	}
	
	/**
	 * 
	 * @param date
	 * @return "dd de MM de aaaa"
	 */
	public static String dateAStringLONG(Date date) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.LONG);
		String s =  df.format(date);
		return s;
	}
	
	/**
	 * 
	 * @param date
	 * @return "dia_semana dd de MM de aaaa"
	 */
	public static String dateAStringFULL(Date date) {
		DateFormat df = DateFormat.getDateInstance(DateFormat.FULL);
		String s =  df.format(date);
		return s;
	}	
	
	
	/**
	 * Convierte sola la hora de un Date en String 
	 * @param Day MM dd HH:mm:ss COT yyyy
	 * @return "HH:mm:ss"
	 */
	public static String DateAhoraString(Date date){
		Time time = dateATime(date);
		return timeAString(time);
	}

	
	/**
	 * Convierte un String en Date
	 * @param "MM-dd-yyyy HH:mm:ss"
	 * @return Day MM dd HH:mm:ss COT yyyy 
	 */
	public static Date stringADate(String string){
		SimpleDateFormat sdf  = new SimpleDateFormat("MM-dd-yyyy HH:mm:ss");
		//parse (text -> date)
		Date fecha = null;
		try {
			fecha = sdf.parse(string);
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		return fecha;
	}
	
	/**
	 * Convierte un String en Date
	 * @param "MM-dd-yyyy HH:mm:ss"
	 * @return Day MM dd HH:mm:ss COT yyyy 
	 */
	public static Date stringADateSimple(String string){
		SimpleDateFormat sdf  = new SimpleDateFormat("MM-dd-yyyy");
		//parse (text -> date)
		Date fecha = null;
		try {
			fecha = sdf.parse(string);
		} catch (ParseException e) {
			e.printStackTrace();
		} 
		return fecha;
	}
	
	/**
	 * Convierte un Timestamp en Time
	 * @param yyyy-MM-dd HH:mm:ss.nnn
	 * @return HH:mm:ss
	 */
	public static Time timestampATime(Timestamp timestamp) {
        return new Time(timestamp.getTime());
    }
	
	/**
	 * Convierte un Timestamp en Date
	 * @param yyyy-MM-dd HH:mm:ss.nnn
	 * @return Day MM dd HH:mm:ss COT yyyy
	 */
	public static Date timestampADate(Timestamp timestamp) {
        return new Date(timestamp.getTime());
    }
	
	/**
	 * Convierte un Date en Timestamp 
	 * @param Day MM dd HH:mm:ss COT yyyy
	 * @return yyyy-MM-dd HH:mm:ss.nnn
	 */
	public static Timestamp dateATimeStamp(Date date){
        return new Timestamp(date.getTime());
    }
	
	/**
	 * Convierte un Date en Time
	 * @param Day MM dd HH:mm:ss COT yyyy
	 * @return HH:mm:ss.nnn
	 */
	public static Time dateATime(Date date){
        return new Time(date.getTime());
    }
	
	/**
	 * Convierte un Time en Timestamp
	 * @param HH:mm:ss.nnn
	 * @return yyyy-MM-dd HH:mm:ss.nnn
	 */
	public static Timestamp timeATimestamp(Time time) {
        return new Timestamp(time.getTime());
    }
	
	
	public static Date timeADate(Time time) {
        return new Date(time.getTime());
    }
	
	
	/**
	 * Redondea a un n�mero double a los d�gitos decimales que deseemos
	 * @param numero
	 * @param digitos
	 * @return
	 */
	public static double redondear(double numero, int digitos){
		String val = numero+"";
	    BigDecimal big = new BigDecimal(val);
	    big = big.setScale(digitos, RoundingMode.HALF_UP);
	    return big.doubleValue();
	}
	
	
    
	
}
