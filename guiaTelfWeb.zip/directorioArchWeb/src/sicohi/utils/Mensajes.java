package sicohi.utils;

public interface Mensajes {
	
	public final String  COMMONS_REGISTRO_ENCONTRADO= "Se encontraron resultados exitosamente";
	public final String  COMMONS_REGISTRO_NO_ENCONTRADO= "NO se encontraron resultados";
	public final String  COMMONS_REGISTRO_ACTUALIZADO= "Registro actualizado exitosamente";
	public final String  COMMONS_REGISTRO_NO_ACTUALIZADO= "Registro NO ha sido actualizado.";
	public final String  COMMONS_REGISTRO_ELIMINADO= "Registro eliminado";
	public final String  COMMONS_SELECCIONAR_TIPO_IDENTIFICACION_VALIDACION= "Seleccionar el tipo de identificaci�n C�DULA / RUC / PASAPORTE";
	public final String  COMMONS_MAIL_VACIO= "NO existe un correo electr�nico v�lido";
	
	public final String  COMMONS_TIPO_IDENTIFICACION_NULL= "Seleccionar si desea buscar por C�DULA / RUC / PASAPORTE";
	public final String  COMMONS_CEDULA_NULL= "Ingrese C�DULA / PASAPORTE que desea buscar";
	public final String  COMMONS_BUSCAR_CEDULA= "Buscar la C�DULA / PASAPORTE del usuario que desea registrar en el Sistema";
	public final String  COMMONS_CEDULA_FALLECIDO= "La condici�n del cedulado es FALLECIDO por lo tanto NO es posible registrarlo en el Sistema";
	public final String  COMMONS_CEDULA_FALLECIDO_PROHIBIDO_FORMULARIOS= "La condici�n del cedulado es FALLECIDO por lo tanto NO es posible el ingreso de nuevos formularios";
	public final String  COMMONS_BUSCAR_CEDULA_CLAVE= "Buscar la C�DULA / PASAPORTE del usuario que desea recuperar la clave";
	public final String  COMMONS_IDENTIFICCION_NULL= "Ingrese C�DULA / RUC / PASAPORTE que desea buscar";
	
	public final String  COMMONS_VALIDACION_REGISTROCIVIL_OK= "Datos validados satisfactoriamente en el Registro Civil";
	public final String  COMMONS_VALIDACION_SRI_OK= "Datos validados satisfactoriamente en el SRI";
	public final String  COMMONS_CONEXION_REGISTRO_CIVIL_FALLO= "Datos NO pudieron ser validados en el Registro Civil, espere unos minutos y vuelva a intentarlo";
	public final String  COMMONS_VALIDACION_REGISTROCIVIL_NULL= "Datos NO pudieron ser validados en el Registro Civil";
	public final String  COMMONS_VALIDACION_SRI_NULl= "Datos NO pudieron ser validados en el SRI";
	
	public final String  USUARIO_YA_EXISTE= "Usuario ya se encuentra registrado en el Sistema, NO es posible volver a registrarlo";
	
	public final String  COMMONS_USUARIO_NO_REGISTRADO= "COMPLETE la informaci�n del usuario y clic en GUARDAR";
	public final String  COMMONS_USUARIO_NO_REGISTRADO_CLAVE= "EL usuario NO se encuentra REGISTRADO en el Sistema, NO es posible recuperar clave";
	
	public final String  COMMONS_MAIL_OK= "Notificaci�n ha sido enviada al correo electr�nico exitosamente (Revisar en su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO).";
	public final String  COMMONS_MAIL_FALLO= "Notificaci�n NO ha podido ser enviada al correo electr�nico en este momento. Revise en su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO en el transcurso del d�a, GRACIAS POR SU COMPRENSI�N.";
	
	public final String  REGISTRO_TIPO_IDENTIFICACION_NULL= "Seleccionar el tipo de identificaci�n C�DULA / PASAPORTE";
	
	public final String  USUARIO_CREADO_OK= "Usuario registrado exitosamente.";
	public final String  USUARIO_CREADO_MAIL_OK= "Su USUARIO y CLAVE han sido enviados exitosamente a su correo electr�nico";
	public final String  USUARIO_CREADO_MAIL_FALLO= "Su USUARIO y CLAVE NO han sido enviados a su correo electr�nico en este momento. Revise su correo en el transcurso del d�a, GRACIAS POR SU COMPRENSI�N.";
	
	public final String  USUARIO_CREADO_FALLO= "Usuario NO ha podido ser registrado en el Sistema. Para MAYOR INFORMACI�N escr�banos a: soportearch@arch.gob.ec";
	
	public final String  USUARIO_PERMISOS_OK= "Usuario es un funcionario de la ARCH y se le asignaron permisos exitosamente para ingresar como SOLICITANTE al m�dulo COMERCIALIZACION CLDH.";
	public final String  USUARIO_PERMISOS_FALLO= "NO fueron asignados permisos para ingresar m�dulo COMERCIALIZACION CLDH. Para MAYOR INFORMACI�N escr�banos a: soportearch@arch.gob.ec";
	
	public final String  USUARIO_RECUPERAR_CLAVE_MAIL_OK= "Su NUEVA CLAVE ha sido enviada a su correo electr�nico (Revisar en su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO).";
	public final String  USUARIO_RECUPERAR_CLAVE_MAIL_FALLO= "Su NUEVA CLAVE NO ha sido enviada su correo electr�nico en este momento. Revise en su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO en el transcurso del d�a, GRACIAS POR SU COMPRENSI�N.";
	
	public final String  USUARIO_MAIL_NUEVA_CLAVE ="REVISE en su correo electr�nico su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO, el Sistema le ha enviado una notificaci�n con su nueva clave";
	public final String  USUARIO_MAIL_USUARIO_CLAVE ="REVISE en su correo electr�nico su BANDEJA DE ENTRADA, SPAM o CORREO NO DESEADO, el Sistema le ha enviado una notificaci�n con su USUARIO y CLAVE.";
	
	public final String  BENEFICIARIO_CREADO_OK= "Solicitante creado exitosamente";
	public final String  BENEFICIARIO_ACTUALIZADO_OK= "Datos del beneficiario se actualizaron exitosamente";	
	public final String  BENEFICIARIO_NO_CREADO= "Solicitante NO pudo ser creado en el Sistema";
	public final String  BENEFICIARIO_NO_ACTUALIZADO= "Datos del solicitante NO se actualizaron en el Sistema";
	public final String  BENEFICIARIO_TELEFONO_OBLIGATORIO= "Debe ingresar al menos un tel�fono ya sea convencional o celular.";
	
	public final String  BENEFICIARIO_NO_EXISTE= "Complete la informaci�n del solicitante y clic en GUARDAR DATOS SOLICITANTE";
	public final String  BENEFICIARIO_SI_EXISTE= "Se encontraron resultados exitosamente en el Sistema";
	public final String  BENEFICIARIO_SELECCIONAR_COMBO_ACTIVIDAD= "Actividad a usar combustible *: es obligatorio";	
	
	public final String  BENEFICIARIO_RUC_DUPLICADO_INSERTAR= "NO se ha podido crear el beneficiario. El beneficiario ya se encuentra registrado en el Sistema, c�dula/RUC no puede duplicarse";
	public final String  BENEFICIARIO_RUC_DUPLICADO_ACTUALIZAR= "NO se ha podido actualizar el beneficiario. El beneficiario ya se encuentra registrado en el Sistema, c�dula/RUC no puede duplicarse";
	
	public final String  COMMONS_CEDULA_INVALIDA= "C�dula inv�lida";
	public final String  COMMONS_CEDULA_INVALIDA_COMUNIDAD= "C�dula inv�lida en SOLICITANTES DE LA COMUNIDAD";
	public final String  COMMONS_RUC_INVALIDO= "RUC inv�lido";	
	public final String  BENEFICIARIO_BUSCAR= "Se debe buscar un solicitante con c�dula, RUC o pasaporte para poder guardar los datos";
	
	public final String  COMMONS_CEDULA_ENCONTRADO= "Persona encontrada con �xito";
	public final String  COMMONS_CEDULA_NO_ENCONTRADO= "Persona NO encontrada";
	
	public final String  CUANTIA_PERSONA_RETIRA_OK= "La persona autorizada para retirar ha sido agregada exitosamente";
	public final String  CUANTIA_PERSONA_RETIRA_DATOS_NULL= "Todos los datos de la Persona Autorizada para Retiro son obligatorios*, caso contrario NO se agregar�";
	public final String  CUANTIA_PERSONA_RETIRA_REPETIDA= "La persona seleccionada ya se encuentra agregada. NO es posible volver a agregarla";
	public final String  CUANTIA_PERSONA_RETIRA_SUPERA_MAXIMO= "NO es posible agregar m�s personas. El Sistema permite agregar un m�ximo de 2 personas en estado ACTIVO para retirar el combustible";
	public final String  CUANTIA_PERSONA_RETIRA_PROHIBIDO_ACTIVAR= "NO es posible ACTIVAR persona. El Sistema permite un m�ximo de 2 personas en estado ACTIVO para retirar el combustible";
	public final String  CUANTIA_PERSONA_RETIRA_ACTUALIZAR_OK= "El estado de la persona autorizada para retirar ha sido actualizado exitosamente";
	public final String  CUANTIA_PERSONA_RETIRA_ACTUALIZAR_FALLO= "El estado de la persona autorizada para retirar NO ha sido actualizado";
	
	
	public final String  CUANTIA_SELECCIONAR_TIPO_REQUERIMIENTO= "Debe seleccionar tipo de requerimiento";
	public final String  CUANTIA_SELECCIONAR_BENEFICIARIO= "Complete la informaci�n del solicitante y clic en GUARDAR DATOS SOLICITANTE";
	public final String  CUANTIA_COMUNIDADES_OBLIGATORIO= "Campo ABASTECIMIENTO A COMUNIDADES * es obligatorio";
	public final String  CUANTIA_SELECCIONAR_ACEPTO_CONDICIONES= "Debe LEER Y ACEPTAR los t�rminos del contrato descritos en el cuadro ACEPTACI�N DEL SERVICIO";
	public final String  CUANTIA_SELECCIONAR_CUMPLIMIENTO_REQUISITOS= "Debe LEER Y ACEPTAR que cumple con los requisitos descritos en el cuadro CUMPLIMIENTO DE REQUISITOS";
	
	public final String  CUANTIA_ESTACION_DUPLICADA= "La estaci�n de servicio seleccionada ya se encuentra agregada. NO es posible volver a agregarla";
	public final String  CUANTIA_ESTACION_OTRA_REGIONAL= "La estaci�n de servicio seleccionada NO fue agregada. Las estaciones para abastecimiento deben pertenecer a la misma Regional de la ARCH";
	public final String  CUANTIA_ESTACION_ABASTECIMIENTO_MAXIMO= "NO puede agregar una ESTACI�N DE SERVICIO mas. El Sistema permite agregar un m�ximo de 2 estaciones para abastecimiento";
	
	public final String  CUANTIA_PLACA_ENCONTRADA= "La maquinaria pesada con la placa ingresada fue encontrada y validada en el SRI exitosamente";
	public final String  CUANTIA_INGRESAR_PLACA= "En la columna Placa/Serie debe ingresar la PLACA  de la maquinaria pesada que desea buscar";
	public final String  CUANTIA_INGRESAR_CEDULA= "En la columna C�dula* debe ingresar el n�mero de c�dula de la persona que desea buscar";
	public final String  CUANTIA_PLACA_SRI_NULL= "La placa del veh�culo NO ha podido ser validada en el SRI";
	public final String  CUANTIA_PLACA_DUPLICADA= "EL veh�culo ya se encuentra agregado en la tabla. NO es posible volver a a�adirlo";
	
	public final String CUANTIA_OBLIGATORIO_REQUERIMIENTO= "Requerimiento: * es obligatorio";	
	public final String CUANTIA_OBLIGATORIO_AUT_ANTERIOR= "Tipo Autorizaci�n Anterior: *, N� de Autorizaci�n Anterior: * y Vigencia Autorizaci�n Anterior: * son obligatorios";	
	public final String CUANTIA_AUTORIZACION_ANTERIOR_NO_EXISTE= "N� de Autorizaci�n Electr�nica: * NO EXISTE, verifique que el N� ingresado sea correcto.";	
	public final String CUANTIA_SELECCIONE_TIPO_AUTORIZACION= "Seleccione Tipo Autorizaci�n Anterior: *";
	public final String CUANTIA_SISTEMA_SOLO_BUSCA_ELECTRONICAS= "El Sistema �nicamente puede buscar una AUTORIZACIONES ELECTR�NICAS.";
	
	public final String CUANTIA_OBLIGATORIO_ESTABLECIMIENTO= "N� establecimiento: * es obligatorio";
	public final String CUANTIA_INVALIDO_ESTABLECIMIENTO= "N� establecimiento: * es un n�mero que NO existe o pertenece a un establecimiento CERRADO";
	public final String CUANTIA_INVALIDO_ESTABLECIMIENTO_DUPLICADO= "El N� establecimiento: * ya tiene un formulario ingresado, NO es posible ingresar otro.";
	public final String CUANTIA_INVALIDO_ESTABLECIMIENTO_DUPLICADO_PRIMERA_VEZ= "El N� establecimiento: * ya tiene un formulario ingresado como PRIMERA VEZ, seleccione otro tipo de requerimiento.";
	public final String CUANTIA_EXTINGUIDA= "Para esta identificaci�n existe una Autorizaci�n extinguida por lo tanto NO podr� volver a solicitar una Cuant�a Dom�stica.";
	public final String CUANTIA_INVALIDO_DUPLICADO= "El Solicitante ya tiene un formulario ingresado.";
	public final String CUANTIA_INVALIDO_DUPLICADO_PRIMERA_VEZ= "El Solicitante ya tiene un formulario ingresado como PRIMERA VEZ, seleccione otro tipo de requerimiento.";
	public final String CUANTIA_OBLIGATORIO_ACTIVIDAD= "Actividad a usar el combustible: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_ACTIVIDAD_COMUNIDADES= "En Actividad a usar el combustible: * �nicamente puede seleccionar ABASTECIMIENTO A COMUNIDADES RURALES";
	public final String CUANTIA_OBLIGATORIO_ACTIVIDAD_DIFERENTE_COMUNIDADES= "En Actividad a usar el combustible: * NO puede seleccionar ABASTECIMIENTO A COMUNIDADES RURALES, ya que al iniciar el nuevo formulario usted seleccion� NO en formalario para Abastecimiento a Comunidades.";
	public final String CUANTIA_OBLIGATORIO_CONTRATO= "Tiene contrato: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_PROYECTO= "Nombre proyecto: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_PERSONAS_RETIRA= "Debe ingresar al menos una persona autorizada para retirar combustible.";
	public final String CUANTIA_OBLIGATORIO_SI_TIENE_CONTRATO= "En el campo (Tiene contrato: *) es obligatorio seleccionar la OPCI�N SI, por tratarse de la actividad de CONSTRUCCI�N/VIALIDAD/OBRA CIVIL";
	public final String CUANTIA_OBLIGATORIO_CONTRATO_FECHAS= "Fechas de vigencia del contrato Desde * y Hasta * son obligatorios.";
	public final String CUANTIA_OBLIGATORIO_PERMISO_FECHAS= "Fechas de vigencia del permiso de miner�a artesanal Desde * y Hasta * son obligatorios.";
	public final String CUANTIA_CONTRATO_INICIO_FIN_PROHIBIDO= "Fecha vigencia contrato Hasta debe ser una fecha posterior a Desde";
	public final String CUANTIA_OBLIGATORIO_HECTAREAS= "N� de hectareas: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_ACUERDO= "N� de Acuerdo Ministerial: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_MATRICULA= "N� de Matr�cula de Embarcaci�n: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_DESCRIPCION_ACTIVIDAD= "Descripci�n Actividad: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_RESOLUCION= "N� de Resoluci�n: * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_DIRECCION= "Provincia: *, Cant�n: *, Parroquia: *, Direcci�n: * y Referencia: * son obligatorios";
	public final String CUANTIA_OBLIGATORIO_ESTACIONES= "Debe seleccionar al menos una ESTACI�N DE SERVICIO PARA ABASTECIMIENTO";
	public final String CUANTIA_OBLIGATORIO_MAQUINARIAS= "Debe agregar al menos una MAQUINARIA Y/O EQUIPOS con los que cuenta para realizar su actividad";
	public final String CUANTIA_OBLIGATORIO_GLNS_HORA= "Galones / Hora * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_MAQUINARIA="Maquinaria * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_PRODUCTO="Producto* es obligatorio";
	public final String CUANTIA_OBLIGATORIO_SOLICITANTES_COMUNIDADES= "Debe agregar al menos un SOLICITANTE DE LA COMUNIDAD";
	public final String CUANTIA_OBLIGATORIO_SOLICITANTES_NOMBRE= "Nombre * del SOLICITANTE DE LA COMUNIDAD es obligatorio";
	public final String CUANTIA_OBLIGATORIO_SOLICITANTES_CEDULA= "C�dula * del SOLICITANTE DE LA COMUNIDAD es obligatorio";
	public final String CUANTIA_OBLIGATORIO_SOLICITANTES_SUBTOTAL= "Total * es obligatorio";
	public final String CUANTIA_OBLIGATORIO_FRECUENCIA="Frecuencia de Retiro (EN D�AS) * es obligatorio";
	public final String CUANTIA_VOLUMEN_TOTAL_SUPERADO="El Volumen Total solicitado por producto no puede superar los 2000 galones.";
	
	public final String CUANTIA_GUARDAR_OK= "Formulario guardado con �xito";
	public final String CUANTIA_GUARDAR_FALLO= "El formulario NO ha podido ser guardado con �xito";
	public final String CUANTIA_ANULADA_OK= "Formulario anulado con �xito";
	public final String CUANTIA_ANULADA_FALLO= "El formulario NO ha podido ser anulado con �xito";
	public final String CUANTIA_ACCION_PROHIBIDA= "Acci�n prohibida sobre el Formulario de Solicitud pues se encuentra en estado: ";
	
	public final String CUANTIA_NUMERO_FORMULARIO_NULL= "Ingresar el N� de Formulario que desea buscar";
	public final String CUANTIA_NUMERO_AUTORIZACION_NULL= "Ingresar N� de Autorizaci�n que desea buscar";
	public final String CUANTIA_ENCONTRADA_OTRA_REGIONAL= "Este formulario se encuentra en la Regional ARCH :";
	public final String CUANTIA_ESTADO_FORMULARIO_NULL= "Seleccionar el estado de los Formularios que desea buscar";
	public final String CUANTIA_ESTADO_AUTORIZACION_NULL= "Seleccionar el estado de las Autorizaciones que desea buscar";
	public final String CUANTIA_ESTADO_TRAMITE_NULL= "Seleccionar el estado del Tr�mite que desea buscar";
	
	public final String COMMONS_FECHA_NULL= "Sleccionar tr�mite y fechas Desde (dd/mm/aaaa) y Hasta (dd/mm/aaaa) las cuales desea buscar";	
	public final String COMMONS_FECHA_MAYOR= "La fecha Desde (dd/mm/aaaa) debe ser anterior a la fecha Hasta (dd/mm/aaaa) seleccionada";
	
	public final String CUANTIA_FORMULARIO_OCUPADO= "El formulario esta siendo evaluado por el usuario: ";
	
	public final String CUANTIA_FORMULARIO_HABILITAR= "Si desea realizar alguna acci�n sobre este formulario, esperar a que se habilite o solicitar al usuario que lo desbloquee";
	public final String CUANTIA_AUTORIZACION_HABILITAR= "Si desea realizar alguna acci�n sobre esta Autorizaci�n, esperar a que se habilite o solicitar al usuario que la desbloquee";
	public final String CUANTIA_FORMULARIO_HABILITAR_NO_PERMITIDO= "Usted NO es un usuario permitido para desbloquear el formulario";
	public final String CUANTIA_FORMULARIO_HABILITAR_OK= "El formulario ha sido desbloqueado exitosamente para que otro usuario lo pueda evaluar";
	
	public final String CUANTIA_PROHIBIDO_AUTORIZAR= "NO es posible autorizar el formulario actual, pues se encuentra en estado ";
	
	public final String  COMMONS_IDENTIFICACION_NO_PERMITIDA= "�nicamente puede consultar con el n�mero de c�dula o RUC del propietario de esta Cuenta";
	
	public final String AUTORIZACION_VIGENCIA_OBLIGATORIO= "NO se ha editado la VIGENCIA de la Autorizaci�n. Inicio *, Fin * y Duraci�n * de Vigencia son inv�lidos";
	public final String AUTORIZACION_DURACION_NULL= "Duraci�n * de Vigencia es requerido para calcular fecha Fin";
	public final String AUTORIZACION_INICIO_NULL= "Inicio * de Vigencia es requerido para calcular fecha Fin";
	public final String AUTORIZACION_FECHA_INICIO_FIN_OBLIGATORIOS= "Inicio * y Fin * de Vigencia son obligatorios";
	public final String AUTORIZACION_DURACION_OBLIGATORIO= "Duraci�n (en d�as) * de Vigencia es obligatorio";
	public final String AUTORIZACION_CONFLICTO_FORMULARIO= "Inicio (dd/mm/aaaa): * de Vigencia NO puede ser una fecha anterior a la fecha del Formulario de solicitud";
	public final String AUTORIZACION_CONFLICTO_CONTRATO_INICIO= "Inicio * de Vigencia NO esta dentro de la vigencia del Contrato de Construci�n ";
	public final String AUTORIZACION_CONFLICTO_CONTRATO_FIN= "Duraci�n * de Vigencia NO esta dentro de la vigencia del Contrato de Construci�n ";
	
	public final String TRAMITE_INICIADO_OK= "Tr�mite iniciado con �xito";
	public final String TRAMITE_RETORNADO_OK= "Tr�mite retornado con �xito";
	public final String TRAMITE_FINALIZADO_OK= "Tr�mite finalizado con �xito";
	public final String TRAMITE_INICIADO_FALLO= "Tr�mite NO ha podido ser iniciado con �xito. Comun�que este incidente inmediatamente a MESA DE AYUDA ext 5100.";
	public final String TRAMITE_RETORNADO_FALLO= "Tr�mite NO ha podido ser retornado con �xito. Comun�que este incidente inmediatamente a MESA DE AYUDA ext 5100.";
	public final String TRAMITE_FINALIZADO_FALLO= "Tr�mite NO ha podido ser finalizado con �xito. Comun�que este incidente inmediatamente a MESA DE AYUDA ext 5100.";
	public final String INICIAR_TRAMITE_OBSERVACION_NULL= "NO se ha iniciado el tr�mite, Comentario * es obligatorio";
	public final String RETORNAR_TRAMITE_OBSERVACION_NULL= "NO se ha retornado el tr�mite, Comentario * es obligatorio";
	public final String AUTORIZACION_ACCION_PROHIBIDA= "Acci�n prohibida para esta Autorizaci�n que se encuentra en estado";
	public final String AUTORIZACION_NO_GENERADA= "Acci�n prohibida para esta Autorizaci�n que aun NO ha sido generada y autorizada";
	public final String AUTORIZACION_SUSPENDIDA_OK= "Autorizaci�n suspendida con �xito";
	public final String AUTORIZACION_ANTERIOR_CAMBIO_FALLO= "Autorizaci�n anterior vigente NO ha cambiado a estado Suspendida. Comun�que este incidente inmediatamente a MESA DE AYUDA ext 5100.";
	
	public final String  AUTORIZACION_NO_ENCONTRADA= "Este Formulario de solicitud NO tiene una Autorizaci�n emitida";
	public final String CUANTIA_AUTORIZACION_OCUPADA= "La Autorizaci�n esta siendo evaluado por el usuario: ";
	
	public final String INSPECCION_OBLIGATORIOS= "NO se ha guardado la inspecci�n. Todos los campos de la inspecci�n con * son obligatorios";
	public final String INSPECCION_GUARDADA_OK= "Inspecci�n guardada con �xito";
	public final String INSPECCION_GUARDADA_FALLO= "NO se ha guardado la inspecci�n.";
	
	public final String HISTORICO_OBLIGATORIOS= "NO se ha guardado la validaci�n del formulario. Todos los campos de la validaci�n con * son obligatorios";
	public final String HISTORICO_GUARDA_OK= "EL Formulario de solicitud ha sido calificado como NO V�LIDO exitosamente";
	public final String HISTORICO_ACTUALIZA_OK= "La calificaci�n de formulaio NO V�LIDO ha sido actualizado exitosamente";
	public final String HISTORICO_GUARDADA_FALLO= "NO se ha guardado la calificaci�n de formulaio NO V�LIDO. Comun�que este incidente inmediatamente a MESA DE AYUDA ext 5100";
	public final String CUANTIA_ESTADO_PROHIBIDO_CALIFICAR= "El formulario NO ha podido ser calificado como NO V�LIDO pues se encuentra en estado: ";
	public final String CUANTIA_PROHIBIDO_CALIFICAR= "El formulario NO ha podido ser calificado como NO V�LIDO pues tiene una autorizaci�n en tr�mite ";
}
