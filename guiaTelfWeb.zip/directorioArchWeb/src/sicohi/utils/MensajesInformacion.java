package sicohi.utils;

public interface MensajesInformacion {
	
	public final String  COMMONS_REGISTRO_ENCONTRADO= "Registro encontrado";
	public final String  COMMONS_REGISTRO_NO_ENCONTRADO= "Registro NO existe";
	public final String  COMMONS_REGISTRO_ACTUALIZADO= "Registro actualizado";
	public final String  COMMONS_REGISTRO_ELIMINADO= "Registro eliminado";
	public final String  COMMONS_REGISTRO_INGRESADO= "Registro ingresado Exitosamente";
	public final String  COMMONS_ARCHIVO_CARGADO= "Archivo Cargado Exitosamente";
	
	public final String  BENEFICIARIO_ENCONTRADO= "Beneficiario encontrado";
	public final String  BENEFICIARIO_NO_ENCONTRADO= "Beneficiario NO encontrado";
	public final String  BENEFICIARIO_CREADO= "Beneficiario creado exitosamente";
	public final String  BENEFICIARIO_ACTUALIZADO= "Datos del beneficiario se actualizaron exitosamente";
	
	public final String  BENEFICIARIO_NATURAL= "Beneficiario persona natural";
	public final String  BENEFICIARIO_JURIDICA= "Beneficiario persona juridica";
	
	public final String FALTA_NOMBRES="Por favor ingrese los nombres del funcionario.";
	public final String FALTA_REGIONAL="Por favor ingrese la regional del funcionario.";
	public final String FALTA_TELFONO="Por favor digite un n�mero de tel�fono.";
	public final String FALTA_EXTENSION="Por favor digite la extensi�n del funcionario.";
	public final String FALTA_UNIDAD="Por favor ingrese la unidad del funcionario";
	public final String FALTA_CIUDAD="Por favor ingrese la ciudad del funcionario";
	public final String FALTA_DIRECCION="Por favor ingrese la direcci�n del funcionario";
	public final String FALTA_CE="Por favor ingrese el correo electr�nico del funcionario";
	
	public final String INGRESO_CORRECTO="Registro ingresado correctamente";
	public final String DATOS_NOINGRESADOS="Los datos no han sido ingresados";
	public final String DATOS_ACTUALIZADOS="Los datos han sido actualizados correctamente";
	public final String DATOS_NOACTUALIZADOS="Los datos no han sido actualizados";
}
