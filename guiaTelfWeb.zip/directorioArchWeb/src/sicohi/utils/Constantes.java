package sicohi.utils;

public interface Constantes {
	
	public final String CEDULA = "C";
	public final String RUC = "R";	
	public final String PASAPORTE = "P";
	
	public final String CONDICION_FALLECIDO="FALLECIDO";
	
	public final String BUSCAR_ESTACION_CDI_IDENTIF = "identificador";
	public final String BUSCAR_ESTACION_NOMBRE = "nombre"; 
	public final String BUSCAR_ESTACION_NOMBRE_COMERCIAL = "nombreComercial";
	
	
	public final String FORMULARIO_CONTRATO_SI = "S";
	public final String FORMULARIO_CONTRATO_NO = "N";
	
	public final String ESTADO_INSPECCION_ACTIVA = "S";
	public final String ESTADO_INSPECCION_NO_ACTIVA = "N";
	
	public final String AUTORIZACION_ES_ELECTRONICA = "SI";
	public final String AUTORIZACION_ES_MANUAL = "NO";
	
	public final String URL_INICIO = "faces/protegido/inicio.xhtml";
	public final String URL_CUANTIAS = "faces/protegido/cuantias.xhtml";
	public final String URL_AUTORIZACIONES = "faces/protegido/autorizaciones.xhtml";
	public final String URL_AUTORIZACIONES_ADMIN = "faces/protegido/administracionAut.xhtml";
	

	public final String ESTILO_MOSTRAR="mostrar";;
	public final String ESTILO_OCULTAR="ocultar";
	
	public final double VALOR_MAXIMO_CLDH=2000;
	public final int DIAS_DEL_MES=30;
	
	public final int MAXIMO_PERSONAS_RETIRO=2;
	
	public final int MAXIMO_ESTACIONES_ABASTECIMIENTO=2;
	
	
	public final String ESTACION_SI_ACTIVA = "S";
	public final String ESTACION_NO_ACTIVA = "N";
	
	public final String PERSONA_RETIRA_SI_ACTIVA = "S";
	public final String PERSONA_RETIRA_NO_ACTIVA = "N";
	
	public final String ETIQUETA_FORMULARIO_NO_VALIDO = "FORMULARIO CALIFICADO COMO NO V�LIDO";
	
	/*
	 **************************************************************************
	 VALORES EN BASE DE DATOS
	 **************************************************************************
	 */
	public final int CODIGO_PERFIL_WEB=5;
	public final int CODIGO_PERFIL_FUNCIONARIO=1;
	public final int CODIGO_PERFIL_ADMINISTRADOR=3;
	public final int CODIGO_APLICACION_COMERCIALIZACIZACION_CLDH=7;
	
	public final String ETIQUETA_CENTRO_DISTRIBUCION_REGISTRADO="REGISTRADO";
	public final String ETIQUETA_CENTRO_DISTRIBUCION_SUSPENDIDO="SUSPENDIDO";
	public final String ETIQUETA_CENTRO_DISTRIBUCION_EXTINGUIDO="EXTINGUIDO";
	public final String ETIQUETA_CENTRO_DISTRIBUCION_EN_TRAMITE="EN TR�MITE";
	
	public final String BENEFICIARIO_VALIDADO_NO = "N";
	public final String BENEFICIARIO_VALIDADO_SI = "S";
	
	public final String ESTABLECIMIENTO_ABIERTO = "ABI";
	public final String ESTABLECIMIENTO_CERRADO = "CER";
	
	public final String MAQUINARIA_PROPIA = "P"; 
	public final String MAQUINARIA_ARRENDADA = "A";
	
	public final String ESTADO_ACTIVO_ACTIVIDAD_SECUNDARIA="S";
	public final String ESTADO_ACTIVO_TIPO_REQUERIMIENTO="S";
	
	public final String SI_LISTA_BLANCA="S";
	public final String NO_LISTA_BLANCA="N";
	
	public final String ETIQUETA_SI_LISTA_BLANCA="SI";
	public final String ETIQUETA_NO_LISTA_BLANCA="NO";
	
	public final long CODIGO_CTR_CODIGO_ABASTECIMIENTO_COMUNIDADES=4;
	
	public final int CODIGO_REQUERIMIENTO_NINGUNO=0;
	public final int CODIGO_REQUERIMIENTO_PRIMERA_VEZ=1;
	public final int CODIGO_REQUERIMIENTO_RENOVACION=2;
	public final int CODIGO_REQUERIMIENTO_INCREMENTO=3;
	
	public final int CODIGO_ACTIVIDAD_ABASTECIMIENTO_COMUNIDADES=1;
	public final int CODIGO_ACTIVIDAD_CONSTRUCCION=5;
	public final int CODIGO_ACTIVIDAD_CAMARONERA=4;
	public final int CODIGO_ACTIVIDAD_PESQUERA=9;
	public final int CODIGO_ACTIVIDAD_AGRICOLA=3;
	public final int CODIGO_ACTIVIDAD_VARIOS=8;
	public final int CODIGO_ACTIVIDAD_MINERIA=7;
	
	public final int CODIGO_SUBACTIVIDAD_VIALIDAD_OBRACIVIL=10;	
	public final int CODIGO_SUBACTIVIDAD_ALQUILER_MAQUINARIA=9;
	public final int CODIGO_SUBACTIVIDAD_MANTENIMIENTO_MOVIL=20;
	public final int CODIGO_SUBACTIVIDAD_ABASTECIMIENTO_COMUNIDADES=1;
	
	public final String PERSONA_NATURAL = "N";
	public final String PERSONA_JURIDICA = "J";
	public final String PERSONA_REGISTRO_CIVIL = "R";
	
	public final String ABASTECIMIENTO_COMUNIDADES_SI = "S";
	public final String ABASTECIMIENTO_COMUNIDADES_NO = "N";
	
	public final long CODIGO_FORMULARIO_INGRESADO=1;
	public final long CODIGO_FORMULARIO_PROSESADO=2;
	public final long CODIGO_FORMULARIO_ANULADO=3;
	public final long CODIGO_FORMULARIO_EN_EVALUACION=5;
	
	public final String CODIGO_TIPO_MAQUINARIA_VEHICULO="49";	
		
	public final String BANDERA_CUANTIA_OCUPADO="S";
	public final String BANDERA_CUANTIA_LIBRE="N";
	
	public final String CODIGO_AUTORIZACION_AUTORIZADA="1";
	public final String CODIGO_AUTORIZACION_SUSPENDIDA="2";
	public final String CODIGO_AUTORIZACION_EXTINGUIDA="3";
	public final String CODIGO_AUTORIZACION_CADUCADA="4";
	public final String CODIGO_AUTORIZACION_NEGADA="5";
	public final String CODIGO_AUTORIZACION_GENERADA="6";
	
	
	public final String CODIGO_TRAMITE_INICIADO="1";
	public final String CODIGO_TRAMITE_RETORNADO="2";
	public final String CODIGO_TRAMITE_FINALIZADO="3";
	
	public final String ETIQUETA_AUTORIZACION_AUTORIZADA="AUTORIZADA";
	public final String ETIQUETA_AUTORIZACION_SUSPENDIDA="SUSPENDIDA";
	public final String ETIQUETA_AUTORIZACION_EXTINGUIDA="EXTINGUIDA";
	public final String ETIQUETA_AUTORIZACION_CADUCADA="CADUCADA";
	public final String ETIQUETA_AUTORIZACION_NEGADA="NEGADA";
	public final String ETIQUETA_AUTORIZACION_GENERADA="GENERADA";
	
	public final String ETIQUETA_AUTORIZAR="AUTORIZAR";
	public final String ETIQUETA_SUSPENDER="SUSPENDER";
	public final String ETIQUETA_EXTINGUIR="EXTINGUIR";
	public final String ETIQUETA_NEGAR="NEGAR";
	
	public final String ETIQUETA_TRAMITE_INICIADO="Iniciado";
	public final String ETIQUETA_TRAMITE_RETORNADO="Retornado";
	public final String ETIQUETA_TRAMITE_FINALIZADO="Finalizado";
	
	
}
