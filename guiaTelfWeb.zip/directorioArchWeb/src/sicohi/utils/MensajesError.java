package sicohi.utils;

public interface MensajesError {
	
	public final String  CARGAR_ARCHIVO= "Favor Cargar el Archivo en formato PDF";
	public final String  COMMONS_IDENTIFICCION_NULL= "Ingrese Cedula / RUC que desea buscar";
	public final String  COMMONS_SELECCIONA_ESTADO= "Favor seleccione un estado";
	public final String  BENEFICIARIO_SELECCIONAR_COMBO_ACTIVIDAD= "error de validaci�n: Actividad: requiere un valor";
	
	public final String  COMMONS_CEDULA_INVALIDA= "C�dula inv�lida";
	public final String  COMMONS_RUC_INVALIDO= "RUC inv�lido";	
	public final String  COMMONS_REGISTRO_CIVIL_NULL= "Se perdi� conexion con el Registro Civil, digite manualmente el nombre/Raz�n Social";
	public final String  COMMONS_SRI_NULL= "Se perdi� conexion con el SRI, digite manualmente el nombre/Raz�n Social";
	public final String  COMMONS_CEDULA_NULL= "Debe ingresar la identificaci�n que desea buscar";
	
}
