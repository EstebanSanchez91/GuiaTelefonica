function validarEnteros(evt){
	keynum = (document.all) ? evt.keyCode : evt.which;
	if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13){
		return true;
	}
	else {
		return false;
	}
}

function soloNumeros(e){
	keynum = (document.all) ? e.keyCode : e.which;
	if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 ){
		return true;
	}
	else {
		return false;
	}
}

function validarValores(evt){
	keynum = (document.all) ? evt.keyCode : evt.which;
	if((keynum > 47 && keynum < 58) || keynum == 8 || keynum == 13 || keynum == 46){
		return true;
	}
	else {
		return false;
	}
}


